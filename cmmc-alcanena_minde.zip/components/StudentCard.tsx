
import React from 'react';
import { Student } from '../types';

interface StudentCardProps {
  student: Student;
  onClick: () => void;
}

const StudentCard: React.FC<StudentCardProps> = ({ student, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className="glass p-5 rounded-[2rem] flex items-center gap-5 cursor-pointer hover:border-[#bef264]/60 transition-all active:scale-[0.97] group border border-white/5"
    >
      <div className="w-16 h-16 rounded-[1.5rem] bg-gradient-to-tr from-[#bef264]/20 to-[#14532d]/30 p-[2px] shrink-0 border border-white/5 group-hover:from-[#bef264] transition-all overflow-hidden">
        <img 
          src={student.photoUrl} 
          className="w-full h-full rounded-[1.4rem] object-cover grayscale group-hover:grayscale-0 transition-all duration-500" 
          alt={student.name} 
        />
      </div>
      <div className="flex-1">
        <h3 className="font-black text-xl italic uppercase group-hover:text-[#bef264] transition-colors tracking-tight leading-tight">{student.name}</h3>
        <div className="flex gap-4 text-[10px] font-bold uppercase tracking-widest text-neutral-500 mt-1">
          <span className="text-[#bef264]">{student.age} ANOS</span>
          <span className="opacity-20">•</span>
          <span>Início {student.startYear}</span>
        </div>
      </div>
      <div className="w-8 h-8 rounded-full flex items-center justify-center text-[#bef264] opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
        <i className="fas fa-arrow-right"></i>
      </div>
    </div>
  );
};

export default StudentCard;
