
import React, { useState } from 'react';
import { Post, User } from '../types';

interface SocialFeedProps {
  user: User;
  posts: Post[];
  onCreatePost: (content: string, imageUrl?: string) => void;
  onLike: (postId: string) => void;
  onComment: (postId: string, text: string) => void;
}

const SocialFeed: React.FC<SocialFeedProps> = ({ user, posts, onCreatePost, onLike, onComment }) => {
  const [newPostText, setNewPostText] = useState('');
  const [showForm, setShowForm] = useState(false);

  const approvedPosts = posts.filter(p => p.status === 'approved').sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim()) return;
    onCreatePost(newPostText);
    setNewPostText('');
    setShowForm(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
      {/* Compositor de Elite */}
      {!showForm ? (
        <button 
          onClick={() => setShowForm(true)}
          className="w-full glass p-5 rounded-[2rem] flex items-center gap-5 text-neutral-500 hover:text-neutral-300 transition-all border border-white/5 hover:border-[#bef264]/30"
        >
          <img src={user.photoUrl} className="w-12 h-12 rounded-2xl object-cover grayscale hover:grayscale-0 transition-all" alt="" />
          <span className="font-black italic uppercase text-sm tracking-tighter">o que tens para partilhar hoje?</span>
          <i className="fas fa-plus-circle ml-auto text-[#bef264] text-xl"></i>
        </button>
      ) : (
        <form onSubmit={handleSubmit} className="glass p-6 rounded-[2.5rem] space-y-4 border-[#bef264]/30">
          <textarea 
            autoFocus
            value={newPostText}
            onChange={(e) => setNewPostText(e.target.value)}
            placeholder="o que tens para partilhar hoje?"
            className="w-full bg-transparent border-none text-white placeholder-neutral-600 focus:ring-0 resize-none h-28 font-medium"
          />
          <div className="flex justify-between items-center pt-4 border-t border-white/5">
            <button type="button" onClick={() => setShowForm(false)} className="text-[10px] font-black uppercase text-neutral-500 hover:text-white tracking-widest">Cancelar</button>
            <button type="submit" className="bg-[#bef264] text-black px-8 py-3 rounded-2xl font-black uppercase italic text-xs glow-lime transition-all active:scale-95">Publicar para Aprovação</button>
          </div>
        </form>
      )}

      {/* Feed de Atletas */}
      <div className="space-y-8">
        {approvedPosts.map(post => (
          <div key={post.id} className="glass rounded-[2.5rem] overflow-hidden border border-white/5">
            <div className="p-6 flex items-center gap-4">
              <div className="relative">
                <img src={post.userPhoto} className="w-12 h-12 rounded-2xl object-cover border border-[#bef264]/20" alt="" />
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#bef264] rounded-full border-2 border-black flex items-center justify-center">
                  <i className="fas fa-check text-[6px] text-black"></i>
                </div>
              </div>
              <div>
                <h4 className="font-black italic uppercase tracking-tight text-white">{post.userName}</h4>
                <p className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest">Membro Atleta</p>
              </div>
            </div>

            <div className="px-6 pb-6">
              <p className="text-neutral-300 leading-relaxed font-medium">{post.content}</p>
            </div>

            <div className="px-6 py-4 bg-white/5 flex items-center gap-8">
              <button 
                onClick={() => onLike(post.id)}
                className={`flex items-center gap-2 text-xs font-black uppercase transition-all ${post.likes.includes(user.id) ? 'text-[#bef264]' : 'text-neutral-600 hover:text-white'}`}
              >
                <i className={`${post.likes.includes(user.id) ? 'fas' : 'far'} fa-fire text-lg`}></i>
                {post.likes.length}
              </button>
              <button className="flex items-center gap-2 text-xs font-black uppercase text-neutral-600 hover:text-white transition-all">
                <i className="far fa-comment-dots text-lg"></i>
                {post.comments.length}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SocialFeed;
