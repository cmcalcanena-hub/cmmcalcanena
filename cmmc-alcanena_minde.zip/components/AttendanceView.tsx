
import React, { useState } from 'react';
import { Student } from '../types';

interface AttendanceViewProps {
  currentStudent?: Student;
  allStudents?: Student[];
  canEdit?: boolean;
  onToggleAttendance?: (studentId: string, date: string) => void;
}

type SubView = 'main' | 'stats';

const AttendanceView: React.FC<AttendanceViewProps> = ({ currentStudent, allStudents = [], canEdit, onToggleAttendance }) => {
  const [subView, setSubView] = useState<SubView>('main');
  const [selectedPolo, setSelectedPolo] = useState<'Alcanena' | 'Minde' | null>(null);
  const [activeStudentId, setActiveStudentId] = useState<string | null>(null);
  const [viewDate, setViewDate] = useState(new Date());

  // Define qual estudante mostrar no calendário
  const targetStudent = canEdit 
    ? allStudents.find(s => s.id === activeStudentId)
    : currentStudent;

  // Lógica da Época: 1 Setembro a 31 Julho
  const now = new Date();
  const currentMonth = now.getMonth(); 
  let seasonStartYear = now.getFullYear();
  let seasonEndYear = now.getFullYear();

  if (currentMonth >= 8) { // Setembro ou depois
    seasonEndYear = seasonStartYear + 1;
  } else { // Janeiro a Agosto
    seasonStartYear = seasonEndYear - 1;
  }

  const seasonStart = new Date(seasonStartYear, 8, 1);
  const seasonEnd = new Date(seasonEndYear, 6, 31);

  const getStats = () => {
    const viewMonth = viewDate.getMonth();
    const viewYear = viewDate.getFullYear();

    if (!canEdit && currentStudent) {
      let monthTotal = 0;
      let seasonTotal = 0;

      currentStudent.attendance.forEach(dateStr => {
        const d = new Date(dateStr);
        if (d.getMonth() === viewMonth && d.getFullYear() === viewYear) monthTotal++;
        if (d >= seasonStart && d <= seasonEnd) seasonTotal++;
      });

      return { monthTotal, seasonTotal };
    } else {
      let monthAlcanena = 0;
      let monthMinde = 0;
      let seasonAlcanena = 0;
      let seasonMinde = 0;
      let totalSeason = 0;

      allStudents.forEach(s => {
        s.attendance.forEach(dateStr => {
          const d = new Date(dateStr);
          if (d.getMonth() === viewMonth && d.getFullYear() === viewYear) {
            if (s.location === 'Alcanena') monthAlcanena++;
            else if (s.location === 'Minde') monthMinde++;
          }
          if (d >= seasonStart && d <= seasonEnd) {
            totalSeason++;
            if (s.location === 'Alcanena') seasonAlcanena++;
            else if (s.location === 'Minde') seasonMinde++;
          }
        });
      });
      return { monthAlcanena, monthMinde, seasonAlcanena, seasonMinde, totalSeason };
    }
  };

  const stats = getStats();
  const prevMonth = () => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1));
  const nextMonth = () => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1));

  const getAttendanceCountForDay = (dateStr: string) => {
    return allStudents.filter(s => s.attendance.includes(dateStr)).length;
  };

  const filteredStudents = allStudents
    .filter(s => s.location === selectedPolo)
    .sort((a, b) => a.name.localeCompare(b.name));

  const renderCalendar = (studentData: Student) => {
    const daysInMonth = new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 0).getDate();
    const firstDayOfMonth = new Date(viewDate.getFullYear(), viewDate.getMonth(), 1).getDay();
    const monthName = viewDate.toLocaleDateString('pt-PT', { month: 'long', year: 'numeric' });

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center px-2">
          <button onClick={prevMonth} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-[#bef264]/20 transition-colors">
            <i className="fas fa-chevron-left text-xs"></i>
          </button>
          <h3 className="font-black uppercase italic tracking-widest text-[#bef264] text-sm">{monthName}</h3>
          <button onClick={nextMonth} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-[#bef264]/20 transition-colors">
            <i className="fas fa-chevron-right text-xs"></i>
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1 text-center mb-2">
          {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map(d => (
            <div key={d} className="text-[10px] font-black text-neutral-600 py-2">{d}</div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-2">
          {Array.from({ length: firstDayOfMonth }).map((_, i) => (
            <div key={`empty-${i}`} className="aspect-square"></div>
          ))}
          
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const day = i + 1;
            const dateStr = `${viewDate.getFullYear()}-${(viewDate.getMonth() + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
            const hasAttended = studentData.attendance.includes(dateStr);
            const isToday = new Date().toISOString().split('T')[0] === dateStr;
            const dailyTotal = getAttendanceCountForDay(dateStr);

            return (
              <button 
                key={day} 
                disabled={!canEdit}
                onClick={() => canEdit && onToggleAttendance?.(studentData.id, dateStr)}
                className={`aspect-square rounded-xl flex flex-col items-center justify-center relative transition-all border outline-none text-[10px]
                  ${hasAttended ? 'bg-[#bef264] text-black border-transparent scale-105 shadow-lg glow-lime font-black' : 'bg-white/5 border-white/5 text-neutral-500'} 
                  ${isToday && !hasAttended ? 'border-[#bef264]/50' : ''}
                  ${canEdit ? 'hover:scale-110 active:scale-95 cursor-pointer' : 'cursor-default'}
                `}
              >
                <span>{day}</span>
                {canEdit && dailyTotal > 0 && (
                  <span className={`absolute -top-1 -right-1 min-w-[14px] h-[14px] px-1 rounded-full text-[7px] font-black flex items-center justify-center border border-black/10 ${hasAttended ? 'bg-white/30 text-black' : 'bg-[#eb5d24] text-white shadow-lg'}`}>
                    {dailyTotal}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  // VISTA DO ATLETA (Somente Leitura de Próprias Stats)
  if (!canEdit) {
    if (!currentStudent) return null;
    const athleteStats = stats as { monthTotal: number; seasonTotal: number };
    
    return (
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
        <header className="flex flex-col gap-2">
          <h2 className="text-3xl font-black italic uppercase tracking-tighter">As Minhas Presenças</h2>
          <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-[0.2em]">Resumo Pessoal de Treinos</p>
        </header>

        <div className="grid grid-cols-2 gap-4">
          <div className="glass p-6 rounded-[2rem] border-[#bef264]/40 flex flex-col items-center justify-center text-center bg-gradient-to-br from-[#bef264]/10 to-transparent">
            <span className="text-4xl font-black italic text-[#bef264] tracking-tighter">{athleteStats.monthTotal}</span>
            <p className="text-[9px] font-black uppercase text-white/40 tracking-widest mt-1">Este Mês</p>
          </div>
          <div className="glass p-6 rounded-[2rem] border-white/5 flex flex-col items-center justify-center text-center">
            <span className="text-4xl font-black italic text-white tracking-tighter">{athleteStats.seasonTotal}</span>
            <p className="text-[9px] font-black uppercase text-neutral-600 tracking-widest mt-1">Época {seasonStartYear}/{seasonEndYear.toString().slice(-2)}</p>
          </div>
        </div>

        <section className="glass p-8 rounded-[3rem] border-white/5 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#bef264]/20 to-transparent"></div>
          {renderCalendar(currentStudent)}
          <div className="mt-8 pt-6 border-t border-white/5 text-center">
             <p className="text-[8px] font-bold text-neutral-600 uppercase italic tracking-tighter">
               Calendário informativo • Entra em contacto com o técnico para retificações
             </p>
          </div>
        </section>
      </div>
    );
  }

  // VISTA DO MODERADOR (Abaixo)
  if (subView === 'stats') {
    const adminStats = stats as { monthAlcanena: number; monthMinde: number; seasonAlcanena: number; seasonMinde: number; totalSeason: number };
    return (
      <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
        <header className="flex items-center gap-4">
          <button 
            onClick={() => setSubView('main')}
            className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-[#bef264] hover:bg-[#bef264]/20 transition-all"
          >
            <i className="fas fa-arrow-left"></i>
          </button>
          <div>
            <h2 className="text-3xl font-black italic uppercase tracking-tighter">Estatísticas Gerais</h2>
            <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-[0.2em]">Resumo de Atividade da Época</p>
          </div>
        </header>

        <div className="grid grid-cols-1 gap-6">
          <div className="glass p-8 rounded-[3rem] border-lime relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <i className="fas fa-calendar-alt text-8xl"></i>
            </div>
            <p className="text-neutral-400 text-[10px] font-black uppercase tracking-[0.3em] mb-6">Total Mensal ({viewDate.toLocaleDateString('pt-PT', { month: 'long' })})</p>
            <div className="grid grid-cols-2 gap-8 relative z-10">
              <div className="space-y-2">
                <span className="text-5xl font-black italic text-[#bef264] tracking-tighter block">{adminStats.monthAlcanena}</span>
                <p className="text-[10px] font-black uppercase text-white/60 tracking-widest">Alcanena</p>
              </div>
              <div className="space-y-2 border-l border-white/5 pl-8">
                <span className="text-5xl font-black italic text-[#eb5d24] tracking-tighter block">{adminStats.monthMinde}</span>
                <p className="text-[10px] font-black uppercase text-white/60 tracking-widest">Minde</p>
              </div>
            </div>
          </div>

          <div className="glass p-8 rounded-[3rem] border-white/5 bg-gradient-to-br from-[#bef264]/5 to-transparent space-y-10">
            <div className="flex flex-col items-center text-center">
              <div className="w-14 h-14 rounded-full bg-[#bef264]/10 flex items-center justify-center text-[#bef264] mb-4">
                 <i className="fas fa-trophy text-xl"></i>
              </div>
              <p className="text-neutral-400 text-[10px] font-black uppercase tracking-[0.3em] mb-2">Total Acumulado na Época</p>
              <h3 className="text-6xl font-black italic text-white tracking-tighter mb-2">{adminStats.totalSeason}</h3>
              <p className="text-[10px] font-black uppercase text-[#bef264] tracking-[0.2em] italic">Total Geral de Presenças</p>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-8 border-t border-white/5">
              <div className="text-center space-y-2">
                <span className="text-4xl font-black italic text-[#bef264] tracking-tighter block">{adminStats.seasonAlcanena}</span>
                <p className="text-[10px] font-black uppercase text-white/40 tracking-widest">Alcanena</p>
                <span className="text-[8px] font-bold text-neutral-600 uppercase">Desde 1 Set</span>
              </div>
              <div className="text-center space-y-2 border-l border-white/5 pl-4">
                <span className="text-4xl font-black italic text-[#eb5d24] tracking-tighter block">{adminStats.seasonMinde}</span>
                <p className="text-[10px] font-black uppercase text-white/40 tracking-widest">Minde</p>
                <span className="text-[8px] font-bold text-neutral-600 uppercase">Desde 1 Set</span>
              </div>
            </div>
          </div>
        </div>

        <button 
          onClick={() => setSubView('main')}
          className="w-full py-5 rounded-[2rem] bg-white/5 text-neutral-400 font-black uppercase italic tracking-widest hover:text-white transition-all border border-white/5"
        >
          Voltar à Gestão
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
      <header className="flex flex-col gap-2">
        <h2 className="text-3xl font-black italic uppercase tracking-tighter">Marcar Presença</h2>
        <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-[0.2em]">Painel do Moderador</p>
      </header>

      <div className="grid grid-cols-2 gap-4">
        <button 
          onClick={() => setSelectedPolo('Alcanena')}
          className={`col-span-1 py-8 rounded-[2.5rem] border transition-all flex flex-col items-center gap-3 relative overflow-hidden group ${selectedPolo === 'Alcanena' ? 'bg-[#bef264] text-black border-transparent shadow-xl glow-lime' : 'glass text-neutral-400 border-white/5 hover:border-[#bef264]/30'}`}
        >
          <div className={`absolute top-0 right-0 p-4 opacity-10 transition-transform group-hover:scale-110 ${selectedPolo === 'Alcanena' ? 'text-black' : 'text-white'}`}>
             <i className="fas fa-location-dot text-4xl"></i>
          </div>
          <i className={`fas fa-running text-2xl transition-transform group-hover:-translate-y-1 ${selectedPolo === 'Alcanena' ? 'text-black' : 'text-[#bef264]'}`}></i>
          <span className="text-sm font-black uppercase italic tracking-widest">Alcanena</span>
        </button>

        <button 
          onClick={() => setSelectedPolo('Minde')}
          className={`col-span-1 py-8 rounded-[2.5rem] border transition-all flex flex-col items-center gap-3 relative overflow-hidden group ${selectedPolo === 'Minde' ? 'bg-[#bef264] text-black border-transparent shadow-xl glow-lime' : 'glass text-neutral-400 border-white/5 hover:border-[#bef264]/30'}`}
        >
          <div className={`absolute top-0 right-0 p-4 opacity-10 transition-transform group-hover:scale-110 ${selectedPolo === 'Minde' ? 'text-black' : 'text-white'}`}>
             <i className="fas fa-location-dot text-4xl"></i>
          </div>
          <i className={`fas fa-walking text-2xl transition-transform group-hover:-translate-y-1 ${selectedPolo === 'Minde' ? 'text-black' : 'text-[#eb5d24]'}`}></i>
          <span className="text-sm font-black uppercase italic tracking-widest">Minde</span>
        </button>

        <button 
          onClick={() => setSubView('stats')}
          className="col-span-2 py-6 rounded-[2rem] glass border border-white/5 flex items-center justify-center gap-4 group hover:border-[#bef264]/50 transition-all"
        >
          <div className="w-10 h-10 rounded-full bg-[#bef264]/10 flex items-center justify-center text-[#bef264] group-hover:bg-[#bef264] group-hover:text-black transition-all">
            <i className="fas fa-chart-line"></i>
          </div>
          <div className="text-left">
            <span className="block text-xs font-black uppercase italic tracking-widest text-white group-hover:text-[#bef264] transition-colors">Estatísticas Gerais</span>
            <span className="block text-[8px] font-bold text-neutral-500 uppercase tracking-tighter">Totais Mensais e Acumulados</span>
          </div>
          <i className="fas fa-chevron-right ml-auto mr-6 text-neutral-700 group-hover:text-[#bef264] transition-all group-hover:translate-x-1"></i>
        </button>
      </div>

      {selectedPolo && (
        <section className="space-y-4 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="flex items-center justify-between px-4">
            <h3 className="text-[10px] font-black uppercase text-neutral-600 tracking-[0.3em]">Lista de Atletas - {selectedPolo}</h3>
            <span className="text-[9px] font-bold text-[#bef264] bg-[#bef264]/5 px-3 py-1 rounded-full border border-[#bef264]/10 uppercase tracking-widest">
              {filteredStudents.length} Total
            </span>
          </div>
          <div className="glass rounded-[2.5rem] overflow-hidden border border-white/5 shadow-2xl">
            <div className="divide-y divide-white/5">
              {filteredStudents.map(s => (
                <button 
                  key={s.id}
                  onClick={() => {
                    setActiveStudentId(s.id);
                    setViewDate(new Date()); 
                  }}
                  className="w-full p-6 flex items-center justify-between hover:bg-white/5 transition-all group relative overflow-hidden"
                >
                  <div className="absolute inset-y-0 left-0 w-1 bg-[#bef264] opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <div className="flex items-center gap-4 text-left">
                    <div className="w-10 h-10 rounded-xl overflow-hidden border border-white/10 group-hover:border-[#bef264]/40 transition-colors bg-white/5">
                      <img src={s.photoUrl} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" alt="" />
                    </div>
                    <div>
                      <span className="block font-black uppercase italic text-sm text-neutral-300 group-hover:text-white tracking-tight transition-colors">{s.name}</span>
                      <span className="text-[8px] font-bold text-neutral-600 uppercase tracking-widest">{s.attendance.length} presenças registadas</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <i className="fas fa-calendar-check text-neutral-700 group-hover:text-[#bef264] transition-colors"></i>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>
      )}

      {activeStudentId && targetStudent && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="glass w-full max-w-md rounded-[3rem] border-[#bef264]/30 shadow-2xl relative p-8 animate-in zoom-in-95 duration-300 overflow-y-auto max-h-[90vh]">
            <header className="flex justify-between items-start mb-8">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-[#bef264]/20 shadow-lg bg-white/5">
                  <img src={targetStudent.photoUrl} className="w-full h-full object-cover" alt="" />
                </div>
                <div>
                  <h4 className="font-black uppercase italic text-xl text-white tracking-tight leading-none mb-1">{targetStudent.name}</h4>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#bef264] animate-pulse"></span>
                    <p className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest">Controlo de Presenças</p>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setActiveStudentId(null)}
                className="w-10 h-10 rounded-2xl bg-white/5 text-neutral-500 flex items-center justify-center hover:bg-red-500/20 hover:text-red-500 transition-all border border-white/5"
              >
                <i className="fas fa-times"></i>
              </button>
            </header>

            {renderCalendar(targetStudent)}

            <div className="mt-8 pt-6 border-t border-white/5 space-y-4">
              <div className="flex justify-around items-center">
                <div className="text-center">
                   <span className="block text-2xl font-black italic text-[#bef264]">{targetStudent.attendance.length}</span>
                   <span className="text-[8px] font-black uppercase text-neutral-600 tracking-widest">Treinos Totais</span>
                </div>
                <div className="w-px h-8 bg-white/5"></div>
                <div className="text-center">
                   <span className="block text-xl font-black italic text-white">{targetStudent.location}</span>
                   <span className="text-[8px] font-black uppercase text-neutral-600 tracking-widest">Pólo Base</span>
                </div>
              </div>
              <button 
                onClick={() => setActiveStudentId(null)}
                className="w-full py-4 bg-[#bef264] text-black font-black uppercase italic text-xs rounded-2xl glow-lime mt-4"
              >
                Guardar e Sair
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttendanceView;
