
import React, { useState } from 'react';
import { Notice, User } from '../types';

interface InformationViewProps {
  user: User;
  notices: Notice[];
  onAddNotice: (notice: Omit<Notice, 'id' | 'timestamp'>) => void;
}

const InformationView: React.FC<InformationViewProps> = ({ user, notices, onAddNotice }) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({ title: '', content: '', imageUrl: '' });

  const isAdmin = user.role === 'trainer';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.content) return;
    onAddNotice({
      ...formData,
      priority: 'normal' // Mantido por compatibilidade com o tipo, mas ignorado na visualização
    });
    setFormData({ title: '', content: '', imageUrl: '' });
    setShowAddForm(false);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black italic uppercase tracking-tighter">Informações</h2>
          <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-[0.2em]">Comunicados Oficiais CMMC</p>
        </div>
        {isAdmin && (
          <button 
            onClick={() => setShowAddForm(!showAddForm)}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${showAddForm ? 'bg-red-500/20 text-red-500 border border-red-500/20' : 'bg-[#bef264] text-black shadow-lg glow-lime'}`}
          >
            <i className={`fas ${showAddForm ? 'fa-times' : 'fa-plus'}`}></i>
          </button>
        )}
      </header>

      {/* Admin Creation Form */}
      {showAddForm && (
        <form onSubmit={handleSubmit} className="glass p-6 rounded-[2.5rem] space-y-4 border-[#bef264]/30 animate-in zoom-in-95">
          <input 
            type="text" 
            placeholder="Título do Aviso" 
            className="w-full bg-white/5 border border-white/10 rounded-xl p-4 font-black uppercase italic text-sm placeholder:text-neutral-600 focus:ring-1 focus:ring-[#bef264]"
            value={formData.title}
            onChange={e => setFormData({...formData, title: e.target.value})}
          />
          <textarea 
            placeholder="Conteúdo do comunicado..." 
            className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-sm min-h-[120px] focus:ring-1 focus:ring-[#bef264]"
            value={formData.content}
            onChange={e => setFormData({...formData, content: e.target.value})}
          />
          <input 
            type="text" 
            placeholder="URL da Imagem/Flyer (Opcional)" 
            className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-[10px] font-bold"
            value={formData.imageUrl}
            onChange={e => setFormData({...formData, imageUrl: e.target.value})}
          />
          
          <button type="submit" className="w-full bg-[#bef264] text-black py-4 rounded-2xl font-black uppercase italic text-xs glow-lime">
            Publicar Informação
          </button>
        </form>
      )}

      {/* Notices List */}
      <div className="space-y-6">
        {notices.length === 0 ? (
          <div className="glass p-16 rounded-[2.5rem] text-center border-dashed border-white/10">
            <i className="fas fa-bullhorn text-4xl text-neutral-800 mb-4"></i>
            <p className="text-neutral-500 font-bold uppercase text-[10px] tracking-widest italic">Sem novos avisos de momento</p>
          </div>
        ) : (
          notices.map(notice => (
            <div key={notice.id} className="glass rounded-[2.5rem] overflow-hidden border border-white/5 transition-all">
              {notice.imageUrl && (
                <div className="w-full aspect-video overflow-hidden border-b border-white/5">
                  <img src={notice.imageUrl} className="w-full h-full object-cover" alt="Flyer" />
                </div>
              )}
              <div className="p-8 space-y-3">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] font-black uppercase text-neutral-500 tracking-[0.2em]">
                    {new Date(notice.timestamp).toLocaleDateString('pt-PT', { day: '2-digit', month: 'long' })}
                  </span>
                  <span className="bg-[#bef264]/10 text-[#bef264] text-[8px] font-black uppercase px-2 py-1 rounded tracking-widest border border-[#bef264]/20">
                    últimas
                  </span>
                </div>
                <h3 className="text-xl font-black italic uppercase tracking-tight text-white">{notice.title}</h3>
                <p className="text-neutral-400 text-sm leading-relaxed whitespace-pre-wrap">{notice.content}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default InformationView;
