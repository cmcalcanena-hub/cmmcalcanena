
// Funcionalidade de IA desativada conforme solicitado.
export const analyzeStudentProgress = async (_student: any): Promise<string> => {
  return "Funcionalidade de análise por IA removida.";
};
