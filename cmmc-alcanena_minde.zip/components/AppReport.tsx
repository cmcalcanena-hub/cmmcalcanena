
import React from 'react';
import { AppPlan } from '../types';

interface AppReportProps {
  plan: AppPlan;
}

const AppReport: React.FC<AppReportProps> = ({ plan }) => {
  return (
    <div className="space-y-8">
      {/* Title & Tagline */}
      <section className="glass p-8 rounded-3xl border-l-4 border-l-blue-500">
        <div className="flex justify-between items-start mb-4">
          <span className="text-xs font-bold uppercase tracking-widest text-blue-400">Blueprint Gerado</span>
          <span className="px-3 py-1 bg-blue-500/10 text-blue-400 text-xs rounded-full border border-blue-500/20">Ready for Dev</span>
        </div>
        <h1 className="text-4xl font-black text-white mb-2">{plan.name}</h1>
        <p className="text-xl text-blue-200 font-medium italic mb-6">"{plan.tagline}"</p>
        
        <div className="flex flex-col md:flex-row gap-8 mt-8 border-t border-slate-700 pt-8">
          <div className="flex-1">
            <h4 className="text-sm font-bold text-slate-400 uppercase mb-2">Público Alvo</h4>
            <p className="text-slate-200">{plan.targetAudience}</p>
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-bold text-slate-400 uppercase mb-2">Modelo de Negócio</h4>
            <p className="text-slate-200">{plan.businessModel}</p>
          </div>
        </div>
      </section>

      {/* Key Features */}
      <section className="space-y-4">
        <h3 className="text-2xl font-bold text-white flex items-center gap-3">
          <i className="fas fa-star text-yellow-500"></i> Funcionalidades Principais
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {plan.keyFeatures.map((feature, idx) => (
            <div key={idx} className="glass p-6 rounded-2xl hover:border-blue-500/50 transition-colors">
              <h4 className="font-bold text-white mb-2 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px]">{idx + 1}</span>
                {feature.title}
              </h4>
              <p className="text-slate-400 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Tech Stack */}
      <section className="space-y-4">
        <h3 className="text-2xl font-bold text-white flex items-center gap-3">
          <i className="fas fa-code text-indigo-500"></i> Tech Stack Recomendada
        </h3>
        <div className="overflow-hidden rounded-2xl border border-slate-700">
          <table className="w-full text-left bg-slate-900/50 backdrop-blur-md">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Categoria</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Sugestão</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Por que?</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {plan.techStack.map((tech, idx) => (
                <tr key={idx} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 font-bold text-blue-400">{tech.category}</td>
                  <td className="px-6 py-4 text-white font-medium">{tech.suggestion}</td>
                  <td className="px-6 py-4 text-slate-400 text-sm">{tech.reasoning}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* MVP Roadmap */}
      <section className="space-y-4">
        <h3 className="text-2xl font-bold text-white flex items-center gap-3">
          <i className="fas fa-route text-green-500"></i> Roadmap para MVP
        </h3>
        <div className="glass p-8 rounded-3xl relative overflow-hidden">
          <div className="absolute left-10 top-12 bottom-12 w-0.5 bg-gradient-to-b from-blue-500 to-indigo-500 opacity-20 hidden md:block"></div>
          <div className="space-y-8 relative">
            {plan.mvpSteps.map((step, idx) => (
              <div key={idx} className="flex gap-6 items-start">
                <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-white font-bold shrink-0 z-10 shadow-lg">
                  {idx + 1}
                </div>
                <div className="pt-1">
                  <p className="text-slate-200 text-lg leading-snug">{step}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default AppReport;
