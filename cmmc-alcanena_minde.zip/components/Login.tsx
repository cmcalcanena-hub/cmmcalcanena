
import React, { useState } from 'react';
import { User } from '../types';
import Logo from './Logo';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [loading, setLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSocialLogin = (provider: 'google' | 'facebook', role: 'trainer' | 'student') => {
    setLoading(provider + role);
    setError(null);

    // Simulação de delay de rede
    setTimeout(() => {
      const email = role === 'trainer' ? 'cmcalcanena@gmail.com' : `atleta_${Math.floor(Math.random() * 100)}@gmail.com`;
      const name = role === 'trainer' ? 'Administrador CMMC' : 'Atleta Registado';
      
      // Regra: Apenas o email específico pode ser moderador
      if (role === 'trainer' && email !== 'cmcalcanena@gmail.com') {
        setError('Acesso negado. Apenas o administrador oficial tem permissão.');
        setLoading(null);
        return;
      }

      onLogin({
        id: role === 'trainer' ? 'mod_001' : Math.random().toString(36).substr(2, 9),
        name: name,
        email: email,
        photoUrl: role === 'trainer' 
          ? 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=100'
          : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=100',
        role: role
      });
      setLoading(null);
    }, 1200);
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-6 bg-[#050805]">
      <div className="glass w-full max-w-md p-10 rounded-[3rem] border border-lime shadow-2xl relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-[#bef264] opacity-5 blur-[100px]"></div>
        
        <div className="text-center space-y-2 mb-10 relative z-10">
          <div className="flex justify-center mb-4">
            <Logo size="xl" />
          </div>
          <div className="space-y-0">
            <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em] leading-none">Centro Municipal de Marcha e Corrida</p>
            <h1 className="text-4xl font-black tracking-tighter text-[#bef264] uppercase italic">
              ALCANENA
            </h1>
          </div>
        </div>

        <div className="space-y-6 relative z-10">
          <div className="space-y-4">
            <h3 className="text-[10px] font-black uppercase text-center text-neutral-500 tracking-[0.3em]">Registo de Atletas</h3>
            
            <button
              onClick={() => handleSocialLogin('google', 'student')}
              className="w-full flex items-center justify-center gap-3 bg-white text-black py-4 rounded-2xl font-black hover:scale-[1.02] transition-all active:scale-95 uppercase text-xs"
            >
              <i className="fab fa-google text-lg"></i>
              Registar com Google
            </button>

            <button
              onClick={() => handleSocialLogin('facebook', 'student')}
              className="w-full flex items-center justify-center gap-3 bg-[#1877F2] text-white py-4 rounded-2xl font-black hover:scale-[1.02] transition-all active:scale-95 uppercase text-xs shadow-lg shadow-[#1877F2]/20"
            >
              <i className="fab fa-facebook text-lg"></i>
              Registar com Facebook
            </button>
          </div>

          <div className="relative py-4">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/5"></div></div>
            <div className="relative flex justify-center text-[10px] uppercase font-bold"><span className="bg-[#0b120b] px-4 text-neutral-700 tracking-tighter">Acesso Restrito</span></div>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => handleSocialLogin('google', 'trainer')}
              className="w-full flex items-center justify-center gap-3 bg-neutral-900 text-white py-4 rounded-2xl font-black hover:bg-neutral-800 transition-all border border-lime/30 uppercase text-xs group"
            >
              <i className="fas fa-shield-halved text-xs text-[#bef264] group-hover:scale-125 transition-transform"></i>
              Moderador
            </button>
            <p className="text-[8px] text-neutral-600 font-bold uppercase text-center tracking-widest px-8">
              Apenas para o email oficial: cmcalcanena@gmail.com
            </p>
          </div>

          {error && (
            <div className="mt-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-black uppercase text-center animate-in fade-in zoom-in-95">
              <i className="fas fa-triangle-exclamation mr-2"></i>
              {error}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Login;
