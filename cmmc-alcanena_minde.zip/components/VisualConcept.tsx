
import React from 'react';

interface VisualConceptProps {
  imageUrl?: string;
}

const VisualConcept: React.FC<VisualConceptProps> = ({ imageUrl }) => {
  return (
    <div className="sticky top-8 space-y-4">
      <h3 className="text-xl font-bold text-white flex items-center gap-3">
        <i className="fas fa-palette text-pink-500"></i> Conceito Visual
      </h3>
      <div className="glass p-4 rounded-3xl overflow-hidden group">
        <div className="aspect-[9/16] bg-slate-800 rounded-2xl flex items-center justify-center overflow-hidden relative border border-slate-700 shadow-2xl">
          {imageUrl ? (
            <>
              <img 
                src={imageUrl} 
                alt="App Concept" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                <button 
                  onClick={() => window.open(imageUrl, '_blank')}
                  className="w-full py-3 bg-white/20 backdrop-blur-md text-white font-bold rounded-xl border border-white/20 hover:bg-white/30 transition-all"
                >
                  Ver em Tela Cheia
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center gap-4 text-slate-500 p-8 text-center">
              <div className="w-12 h-12 border-2 border-slate-700 border-t-blue-500 rounded-full animate-spin"></div>
              <p className="text-sm font-medium">Gerando mockup visual...</p>
            </div>
          )}
        </div>
      </div>
      <div className="glass p-6 rounded-2xl space-y-3">
        <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Aviso de IA</h4>
        <p className="text-xs text-slate-500 leading-relaxed">
          O design acima é uma representação conceitual gerada por IA baseada na sua ideia. Use-o como inspiração para o seu UI Designer.
        </p>
      </div>
    </div>
  );
};

export default VisualConcept;
