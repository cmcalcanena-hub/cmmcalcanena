
import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

const Logo: React.FC<LogoProps> = ({ className = '', size = 'md' }) => {
  const dimensions = {
    sm: 'w-10 h-10',
    md: 'w-16 h-16',
    lg: 'w-24 h-24',
    xl: 'w-32 h-32'
  };

  return (
    <div className={`${dimensions[size]} ${className} flex items-center justify-center relative`}>
      <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-[0_0_12px_rgba(163,207,33,0.3)]">
        {/* Forma Verde Limão (Esquerda/Base) */}
        <path 
          d="M15 30C15 30 10 45 15 65C20 85 45 90 45 90L40 70C40 70 25 70 20 55C15 40 25 30 25 30L15 30Z" 
          fill="#a3cf21" 
        />
        
        {/* Braço superior Verde Limão */}
        <path 
          d="M30 35C30 35 35 30 45 32C55 34 58 40 58 40L50 45C50 45 45 38 40 40C35 42 32 45 32 45L30 35Z" 
          fill="#a3cf21" 
        />

        {/* Corpo Central Verde Escuro */}
        <path 
          d="M45 40C45 40 42 50 48 60C54 70 55 75 50 85L60 75C60 75 62 65 58 55C54 45 50 40 50 40H45Z" 
          fill="#144225" 
        />
        
        {/* Braço/Extensão Direita Verde Escuro */}
        <path 
          d="M50 45C50 45 60 42 75 42V38C75 38 60 38 50 42V45Z" 
          fill="#144225" 
        />

        {/* Perna/Swoosh Laranja */}
        <path 
          d="M45 50C45 50 38 60 40 75C42 90 60 100 60 100L55 85C55 85 48 80 48 70C48 60 55 55 55 55L45 50Z" 
          fill="#eb5d24" 
        />

        {/* Cabeça Verde Escuro */}
        <circle cx="58" cy="25" r="7" fill="#144225" />
        <circle cx="58" cy="25" r="3" fill="#050805" />
      </svg>
    </div>
  );
};

export default Logo;
