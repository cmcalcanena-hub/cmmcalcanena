
import React, { useState } from 'react';
import { Student, TrainingLog } from '../types';

interface StudentDetailProps {
  student: Student;
  isAdmin?: boolean;
  canEdit?: boolean;
  onAddLog?: (log: Omit<TrainingLog, 'id'>) => void;
  onRemoveLog?: (logId: string) => void;
  onUpdateLog?: (log: TrainingLog) => void;
  onToggleAttendance?: (date: string) => void;
  onUpdatePhoto?: () => void;
}

const StudentDetail: React.FC<StudentDetailProps> = ({ 
  student, 
  isAdmin, 
  canEdit, 
  onAddLog, 
  onRemoveLog, 
  onUpdateLog, 
  onToggleAttendance, 
  onUpdatePhoto 
}) => {
  const [expandedExercise, setExpandedExercise] = useState<string | null>(null);
  const [newLog, setNewLog] = useState({ exercise: '', result: '', date: new Date().toISOString().split('T')[0] });
  
  // Estados para edição inline
  const [editingLogId, setEditingLogId] = useState<string | null>(null);
  const [editValues, setEditValues] = useState<{ date: string; result: string }>({ date: '', result: '' });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLog.exercise || !newLog.result) return;
    onAddLog?.({
      exercise: newLog.exercise,
      result: newLog.result,
      date: newLog.date
    });
    setNewLog({ exercise: '', result: '', date: new Date().toISOString().split('T')[0] });
  };

  const startEditing = (log: TrainingLog) => {
    setEditingLogId(log.id);
    setEditValues({ date: log.date, result: log.result });
  };

  const cancelEditing = () => {
    setEditingLogId(null);
    setEditValues({ date: '', result: '' });
  };

  const saveEdit = (log: TrainingLog) => {
    if (!editValues.result || !editValues.date) return;
    onUpdateLog?.({
      ...log,
      date: editValues.date,
      result: editValues.result
    });
    setEditingLogId(null);
  };

  const getPersonalRecord = (history: TrainingLog[]) => {
    if (history.length === 0) return "-";
    const isTime = history[0].result.includes(':');
    if (isTime) {
      return [...history].sort((a, b) => {
        const pad = (s: string) => s.split(':').map(part => part.padStart(2, '0')).join(':');
        return pad(a.result).localeCompare(pad(b.result));
      })[0].result;
    } else {
      const getVal = (r: string) => parseFloat(r.replace(/[^0-9.]/g, '')) || 0;
      return [...history].sort((a, b) => getVal(b.result) - getVal(a.result))[0].result;
    }
  };

  const exercisesData = student.evolution.reduce((acc, log) => {
    if (!acc[log.exercise]) acc[log.exercise] = [];
    acc[log.exercise].push(log);
    return acc;
  }, {} as Record<string, TrainingLog[]>);

  Object.keys(exercisesData).forEach(ex => {
    exercisesData[ex].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });

  const exerciseNames = Object.keys(exercisesData).sort();
  const totalRecords = exerciseNames.length;
  const attendanceRate = student.attendance.length;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
      {/* Profile Header */}
      <div className="flex flex-col items-center gap-6 mb-8">
        <div className="relative group">
          <div className="w-36 h-36 rounded-[2.5rem] bg-gradient-to-tr from-[#bef264] via-[#14532d] to-[#eb5d24] p-[3px] shadow-2xl shadow-[#bef264]/20 transition-all group-hover:scale-105">
            <div className="w-full h-full rounded-[2.4rem] bg-[#050805] overflow-hidden">
              <img src={student.photoUrl} className="w-full h-full object-cover transition-all duration-700" alt={student.name} />
            </div>
          </div>
          {canEdit && (
            <button 
              onClick={onUpdatePhoto}
              className="absolute -bottom-2 -right-2 w-12 h-12 bg-[#bef264] text-black rounded-2xl flex items-center justify-center shadow-xl glow-lime hover:scale-110 active:scale-95 transition-all border-4 border-[#050805]"
            >
              <i className="fas fa-camera"></i>
            </button>
          )}
        </div>
        <div className="text-center space-y-1">
          <h2 className="text-3xl font-black italic uppercase tracking-tighter text-white">{student.name}</h2>
          <div className="flex items-center justify-center gap-4 text-[10px] font-bold uppercase tracking-widest text-[#bef264]">
            <span>Polo {student.location}</span>
          </div>
        </div>
      </div>

      {/* Statistics Dashboard */}
      <div className="grid grid-cols-3 gap-3">
        <div className="glass p-4 rounded-3xl border-white/5 text-center flex flex-col items-center justify-center">
          <i className="fas fa-calendar-check text-[#bef264] text-xs mb-2 opacity-50"></i>
          <span className="text-xl font-black italic text-white leading-none">{attendanceRate}</span>
          <span className="text-[7px] font-black uppercase text-neutral-500 tracking-widest mt-1">Presenças</span>
        </div>
        <div className="glass p-4 rounded-3xl border-lime text-center flex flex-col items-center justify-center">
          <i className="fas fa-trophy text-[#eb5d24] text-xs mb-2 opacity-50"></i>
          <span className="text-xl font-black italic text-[#bef264] leading-none">{totalRecords}</span>
          <span className="text-[7px] font-black uppercase text-neutral-500 tracking-widest mt-1">Exercícios</span>
        </div>
        <div className="glass p-4 rounded-3xl border-white/5 text-center flex flex-col items-center justify-center">
          <i className="fas fa-fire text-[#bef264] text-xs mb-2 opacity-50"></i>
          <span className="text-xl font-black italic text-white leading-none">{student.startYear}</span>
          <span className="text-[7px] font-black uppercase text-neutral-500 tracking-widest mt-1">Desde</span>
        </div>
      </div>

      {/* Biography Data */}
      <section className="glass p-8 rounded-[2.5rem] relative overflow-hidden border-[#bef264]/10">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#bef264] opacity-5 rounded-full blur-3xl"></div>
        <h3 className="text-[10px] font-black uppercase text-[#bef264] tracking-[0.3em] mb-8 border-l-2 border-[#bef264] pl-3">
          Dados Biográficos
        </h3>
        
        <div className="grid grid-cols-2 gap-8">
          <div className="space-y-1">
            <p className="text-neutral-600 text-[9px] font-black uppercase tracking-widest">Idade</p>
            <p className="text-xl font-black italic uppercase tracking-tighter text-[#bef264]">{student.age} Anos</p>
          </div>
          <div className="space-y-1">
            <p className="text-neutral-600 text-[9px] font-black uppercase tracking-widest">Início no CMMC</p>
            <p className="text-xl font-black italic uppercase tracking-tighter text-white">{student.startYear}</p>
          </div>
        </div>
      </section>

      {/* Add Log (Admin/Owner only) */}
      {canEdit && isAdmin && (
        <section className="glass p-6 rounded-[2rem] border-dashed border-[#bef264]/30 border-2">
          <h4 className="text-[10px] font-black uppercase text-[#bef264] tracking-widest mb-4">Novo Registo de Treino</h4>
          <form onSubmit={handleAdd} className="grid grid-cols-2 gap-3">
            <input 
              type="text" 
              placeholder="Exercício" 
              className="col-span-2 bg-white/5 border border-white/10 rounded-xl p-3 text-sm font-bold uppercase italic focus:border-[#bef264] outline-none" 
              value={newLog.exercise} 
              onChange={e => setNewLog({...newLog, exercise: e.target.value})} 
            />
            <input 
              type="text" 
              placeholder="Marca (ex: 22:30, 1h15m, 85kg)" 
              className="col-span-2 bg-white/5 border border-white/10 rounded-xl p-3 text-sm font-bold uppercase italic focus:border-[#bef264] outline-none" 
              value={newLog.result} 
              onChange={e => setNewLog({...newLog, result: e.target.value})} 
            />
            <input 
              type="date" 
              className="col-span-2 bg-white/5 border border-white/10 rounded-xl p-3 text-sm font-bold text-[#bef264] outline-none" 
              value={newLog.date} 
              onChange={e => setNewLog({...newLog, date: e.target.value})} 
            />
            <button type="submit" className="col-span-2 bg-[#bef264] text-black py-3 rounded-xl font-black uppercase italic text-xs glow-lime active:scale-95 transition-all">Adicionar Resultado</button>
          </form>
        </section>
      )}

      {/* Evolution History */}
      <section className="space-y-4 pb-12">
        <h3 className="text-[10px] font-black uppercase text-[#bef264] tracking-[0.3em] mb-4 border-l-2 border-[#bef264] pl-3">Histórico de Performance</h3>
        
        <div className="space-y-3">
          {exerciseNames.length > 0 ? exerciseNames.map(exercise => {
            const isExpanded = expandedExercise === exercise;
            const history = exercisesData[exercise];
            const latestResult = history[0].result;
            const personalRecord = getPersonalRecord(history);

            return (
              <div key={exercise} className={`glass rounded-[2rem] overflow-hidden border transition-all duration-300 ${isExpanded ? 'border-[#bef264]' : 'border-white/5'}`}>
                <button 
                  onClick={() => setExpandedExercise(isExpanded ? null : exercise)}
                  className="w-full p-6 flex items-center justify-between group"
                >
                  <div className="text-left">
                    <h4 className={`font-black uppercase italic tracking-tight text-lg transition-colors ${isExpanded ? 'text-[#bef264]' : 'text-white'}`}>
                      {exercise}
                    </h4>
                    <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1">
                      <p className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest">
                        Último: <span className="text-[#bef264]">{latestResult}</span>
                      </p>
                      <span className="text-white/10 hidden sm:inline">|</span>
                      <p className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest">
                        PB: <span className="text-[#eb5d24]">{personalRecord}</span>
                      </p>
                    </div>
                  </div>
                  <div className={`w-8 h-8 rounded-full bg-white/5 flex items-center justify-center transition-transform duration-300 ${isExpanded ? 'rotate-180 bg-[#bef264]/20 text-[#bef264]' : 'text-neutral-500'}`}>
                    <i className="fas fa-chevron-down text-[10px]"></i>
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-6 pb-6 animate-in slide-in-from-top-2 duration-300 overflow-x-auto">
                    <div className="bg-black/20 rounded-2xl overflow-hidden border border-white/5 min-w-[400px]">
                      <table className="w-full text-[10px]">
                        <thead className="bg-white/5 font-black uppercase text-neutral-500 tracking-tighter">
                          <tr>
                            <th className="px-4 py-3 text-left">Data</th>
                            <th className="px-4 py-3 text-right">Marca</th>
                            {canEdit && isAdmin && <th className="px-4 py-3 text-right">Gestão</th>}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {history.map((log) => {
                            const isEditing = editingLogId === log.id;
                            
                            return (
                              <tr key={log.id} className="hover:bg-white/5 transition-colors">
                                <td className="px-4 py-3">
                                  {isEditing ? (
                                    <input 
                                      type="date"
                                      value={editValues.date}
                                      onChange={(e) => setEditValues({ ...editValues, date: e.target.value })}
                                      className="bg-white/10 border border-[#bef264]/30 rounded px-2 py-1 text-white font-bold outline-none text-[9px]"
                                    />
                                  ) : (
                                    <span className="text-neutral-400 font-bold">
                                      {new Date(log.date).toLocaleDateString('pt-PT')}
                                    </span>
                                  )}
                                </td>
                                <td className="px-4 py-3 text-right">
                                  {isEditing ? (
                                    <input 
                                      type="text"
                                      value={editValues.result}
                                      onChange={(e) => setEditValues({ ...editValues, result: e.target.value })}
                                      className="bg-white/10 border border-[#bef264]/30 rounded px-2 py-1 text-[#bef264] font-black italic uppercase outline-none text-[9px] w-24 text-right"
                                    />
                                  ) : (
                                    <span className={`font-black italic uppercase ${log.result === personalRecord ? 'text-[#eb5d24]' : 'text-[#bef264]'}`}>
                                      {log.result}
                                      {log.result === personalRecord && <i className="fas fa-trophy ml-2 text-[8px]"></i>}
                                    </span>
                                  )}
                                </td>
                                {canEdit && isAdmin && (
                                  <td className="px-4 py-3 text-right">
                                    <div className="flex justify-end gap-3">
                                      {isEditing ? (
                                        <>
                                          <button 
                                            onClick={() => saveEdit(log)}
                                            className="text-emerald-500 hover:scale-125 transition-transform"
                                            title="Guardar Alterações"
                                          >
                                            <i className="fas fa-check"></i>
                                          </button>
                                          <button 
                                            onClick={cancelEditing}
                                            className="text-neutral-500 hover:text-white transition-colors"
                                            title="Cancelar"
                                          >
                                            <i className="fas fa-times"></i>
                                          </button>
                                        </>
                                      ) : (
                                        <>
                                          <button 
                                            onClick={() => startEditing(log)}
                                            className="text-[#bef264]/60 hover:text-[#bef264] p-1 transition-colors"
                                            title="Editar Registo"
                                          >
                                            <i className="fas fa-pencil-alt text-[9px]"></i>
                                          </button>
                                          <button 
                                            onClick={() => {
                                              if (confirm('Eliminar este registo permanentemente?')) onRemoveLog?.(log.id);
                                            }} 
                                            className="text-red-500/40 hover:text-red-500 p-1 transition-colors"
                                            title="Eliminar"
                                          >
                                            <i className="fas fa-trash-alt text-[9px]"></i>
                                          </button>
                                        </>
                                      )}
                                    </div>
                                  </td>
                                )}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            );
          }) : (
            <div className="glass p-12 rounded-[2rem] text-center border-dashed border-white/10">
              <p className="text-neutral-500 font-bold uppercase text-[10px] tracking-widest italic">Sem histórico registado</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default StudentDetail;
