
import React, { useState } from 'react';
import { Post, ContactMessage } from '../types';

interface ModerationPanelProps {
  posts: Post[];
  contactMessages: ContactMessage[];
  onApprove: (postId: string) => void;
  onReject: (postId: string) => void;
  onDeleteMessage?: (msgId: string) => void;
}

const ModerationPanel: React.FC<ModerationPanelProps> = ({ 
  posts, 
  contactMessages, 
  onApprove, 
  onReject,
  onDeleteMessage 
}) => {
  const [tab, setTab] = useState<'posts' | 'messages'>('posts');
  const pendingPosts = posts.filter(p => p.status === 'pending');

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
      {/* Tab Switcher */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-2xl border border-white/5">
        <button 
          onClick={() => setTab('posts')}
          className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${tab === 'posts' ? 'bg-[#bef264] text-black' : 'text-neutral-500'}`}
        >
          Publicações ({pendingPosts.length})
        </button>
        <button 
          onClick={() => setTab('messages')}
          className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${tab === 'messages' ? 'bg-[#bef264] text-black' : 'text-neutral-500'}`}
        >
          Contactos ({contactMessages.length})
        </button>
      </div>

      {tab === 'posts' ? (
        <div className="space-y-6">
          <h3 className="text-sm font-black text-[#bef264] uppercase tracking-widest">Aprovação de Mural</h3>
          {pendingPosts.length === 0 ? (
            <div className="glass p-10 rounded-3xl text-center text-slate-500">
              <i className="fas fa-check-circle text-4xl text-[#bef264] mb-4 opacity-20"></i>
              <p className="text-[10px] font-black uppercase">Tudo limpo!</p>
            </div>
          ) : (
            pendingPosts.map(post => (
              <div key={post.id} className="glass p-6 rounded-3xl border-l-4 border-l-yellow-500 space-y-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <img src={post.userPhoto} className="w-10 h-10 rounded-full border border-white/10" alt="" />
                    <div>
                      <h4 className="font-bold text-sm uppercase italic">{post.userName}</h4>
                      <p className="text-[8px] text-slate-500 font-bold uppercase">{new Date(post.timestamp).toLocaleString('pt-PT')}</p>
                    </div>
                  </div>
                </div>
                <p className="text-slate-200 text-sm leading-relaxed">{post.content}</p>
                <div className="flex gap-3 pt-4">
                  <button onClick={() => onApprove(post.id)} className="flex-1 bg-emerald-600 hover:bg-emerald-500 py-3 rounded-xl font-black uppercase italic text-[10px] transition-all">Aprovar</button>
                  <button onClick={() => onReject(post.id)} className="flex-1 bg-red-600/20 text-red-400 py-3 rounded-xl font-black uppercase italic text-[10px] border border-red-500/20 transition-all">Rejeitar</button>
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="space-y-6">
          <h3 className="text-sm font-black text-[#bef264] uppercase tracking-widest">Mensagens Recebidas</h3>
          {contactMessages.length === 0 ? (
            <div className="glass p-10 rounded-3xl text-center text-slate-500">
              <i className="fas fa-envelope-open text-4xl text-[#bef264] mb-4 opacity-20"></i>
              <p className="text-[10px] font-black uppercase tracking-widest">Sem mensagens novas</p>
            </div>
          ) : (
            contactMessages.map(msg => (
              <div key={msg.id} className="glass p-6 rounded-3xl border-l-4 border-l-blue-500 space-y-3 relative group">
                <button 
                  onClick={() => onDeleteMessage?.(msg.id)}
                  className="absolute top-4 right-4 text-neutral-600 hover:text-red-500 transition-colors"
                >
                  <i className="fas fa-trash-alt text-xs"></i>
                </button>
                <div className="flex flex-col">
                  <h4 className="font-black text-sm uppercase italic text-white">{msg.name}</h4>
                  <span className="text-[8px] font-bold text-neutral-600 uppercase">{new Date(msg.timestamp).toLocaleString('pt-PT')}</span>
                </div>
                <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                  <p className="text-neutral-300 text-xs leading-relaxed italic">"{msg.message}"</p>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default ModerationPanel;
