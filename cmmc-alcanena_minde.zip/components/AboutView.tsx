
import React, { useState } from 'react';
import Logo from './Logo';

type AboutTab = 'overview' | 'history' | 'trainer' | 'signup';

interface AboutViewProps {
  onSendMessage?: (name: string, message: string) => void;
}

const AboutView: React.FC<AboutViewProps> = ({ onSendMessage }) => {
  const [activeTab, setActiveTab] = useState<AboutTab>('overview');
  const [contactForm, setContactForm] = useState({ name: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.message) return;
    onSendMessage?.(contactForm.name, contactForm.message);
    setContactForm({ name: '', message: '' });
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 pb-12">
      <header className="flex flex-col gap-2">
        <h2 className="text-3xl font-black italic uppercase tracking-tighter text-white">Sobre o CMMC</h2>
        <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-[0.2em]">Centro Municipal de Marcha e Corrida</p>
      </header>

      {/* Sub-menu Navigation */}
      <nav className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide no-scrollbar">
        {[
          { id: 'overview', label: 'Geral', icon: 'fa-info-circle' },
          { id: 'history', label: 'História', icon: 'fa-book-open' },
          { id: 'trainer', label: 'O Técnico', icon: 'fa-user-ninja' },
          { id: 'signup', label: 'Inscreve-te', icon: 'fa-id-card' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as AboutTab)}
            className={`flex items-center gap-2 px-6 py-3 rounded-full text-[10px] font-black uppercase italic tracking-widest whitespace-nowrap transition-all border ${
              activeTab === tab.id 
                ? 'bg-[#bef264] text-black border-transparent shadow-lg shadow-[#bef264]/20 scale-105' 
                : 'bg-white/5 text-neutral-500 border-white/10 hover:border-white/20'
            }`}
          >
            <i className={`fas ${tab.icon} text-xs`}></i>
            {tab.label}
          </button>
        ))}
      </nav>

      {/* Content Sections */}
      <div className="space-y-8 animate-in fade-in zoom-in-95 duration-300">
        
        {/* OVERVIEW SECTION */}
        {activeTab === 'overview' && (
          <>
            <div className="glass p-8 rounded-[2.5rem] relative overflow-hidden border-[#bef264]/10">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <Logo size="lg" />
              </div>
              <div className="relative z-10 space-y-4">
                <h3 className="text-[#bef264] font-black italic uppercase text-lg">A Nossa Missão</h3>
                <p className="text-neutral-300 text-sm leading-relaxed">
                  Promover a saúde e o bem-estar da comunidade através da marcha e corrida orientada, garantindo uma prática desportiva segura e adaptada a todas as idades.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="glass p-6 rounded-[2rem] border-white/5 space-y-4">
                <h4 className="font-black uppercase italic text-xl tracking-tight text-[#bef264]">Alcanena</h4>
                <div className="space-y-2 border-t border-white/5 pt-3">
                  <p className="text-[10px] text-white font-black uppercase">2ªs, 4ªs e 6ªs feiras • 18h00</p>
                  <p className="text-[10px] text-neutral-500 font-bold uppercase leading-tight">Estádio Municipal Joaquim Maria Batista</p>
                </div>
              </div>
              <div className="glass p-6 rounded-[2rem] border-white/5 space-y-4">
                <h4 className="font-black uppercase italic text-xl tracking-tight text-[#bef264]">Minde</h4>
                <div className="space-y-2 border-t border-white/5 pt-3">
                  <p className="text-[10px] text-white font-black uppercase">3ªs e 5ªs feiras • 18h30</p>
                  <p className="text-[10px] text-neutral-500 font-bold uppercase leading-tight">Pavilhão Gimnodesportivo de Minde</p>
                </div>
              </div>
            </div>
          </>
        )}

        {/* HISTORY SECTION */}
        {activeTab === 'history' && (
          <div className="glass p-8 rounded-[2.5rem] border-white/5 space-y-6">
            <div className="space-y-4 text-neutral-300 text-sm leading-relaxed">
              <p>O Centro Municipal de Marcha e Corrida (CMMC) nasceu de uma parceria entre o Município de Alcanena e o Programa Nacional de Marcha e Corrida.</p>
              <p>
                A inauguração aconteceu a 22 de fevereiro de 2015 pela Sra. Presidente da Câmara Municipal de Alcanena Fernanda Asseiceira, numa cerimónia apadrilhada pelo ex atleta alcanenense Carlos Calado e pela atleta de Rio Maior Vera Santos. Marcou presença nesta manhã o Prof. Pedro Rocha em representação do Programa Nacional de Marcha e Corrida. numa manhã marcada pela boa disposição numa caminhada urbana pelas ruas da vila de Alcanena.
              </p>
              
              <p>
                Ao longo dos anos o CMMC Alcanena tem dado a oportunidade á populção envolvida de melhorar a sua condição fisica obtendo um estilo de vida mais saudavel, ativo e regular.
              </p>

              <p>
                Os números falam por si, onde a boa afluência aos treinos é bastante notória. Sempre com um espirito de boa disposição que é contagiante a todos os praticantes.
              </p>

              <p>
                Na era COVID-19 o CMMC Alcanena foi desafiado pela impossibilidade de levar ás pessoas o trabalho desenvolvido até então, no entanto várias iniciativas foram levadas a cabo sempre com o objetivo de manter as pessoas unidas. Desde desafios online, desafios respeitando as regras, entrevistas a atletas e agentes do atletismo português etc...
              </p>

              <p>
                Em 2024 surgiu o desafio de ser implementado o Pólo na freguesia de Minde. Uma aposta ganha pois permitiu a mais pessoas ter acesso a este programa.
              </p>

              <p>
                Em 2025 o Centro Municipal de Marcha e Corrida de Alcanena alcançou o Certificado de Excelência Prata com 76 pontos (a somente 4 pontos do nível Ouro).
              </p>

              <div className="pl-4 border-l-2 border-[#bef264]/30 italic text-neutral-400 mt-6">
                "Desde a sua fundação, o objetivo foi combater o sedentarismo e criar um espaço onde cada cidadão pudesse evoluir fisicamente com supervisão técnica" - Carlos Santos, o técnico.
              </div>
            </div>
          </div>
        )}

        {/* TRAINER SECTION */}
        {activeTab === 'trainer' && (
          <div className="glass p-8 rounded-[2.5rem] border-white/5 space-y-6">
            <div className="flex items-center gap-6">
              <div className="w-28 h-28 rounded-[2rem] bg-gradient-to-tr from-[#bef264] to-[#144225] p-[2px] shrink-0 shadow-xl shadow-[#bef264]/20">
                <div className="w-full h-full rounded-[1.9rem] bg-[#050805] flex items-center justify-center overflow-hidden">
                   <img 
                    src="carlos-santos.jpg" 
                    className="w-full h-full object-cover transition-all duration-500 hover:scale-110" 
                    alt="Carlos Santos" 
                    onError={(e) => {
                      // Fallback em caso da imagem não ser encontrada
                      (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1594381898411-846e7d193883?auto=format&fit=crop&q=80&w=300";
                    }}
                   />
                </div>
              </div>
              <div>
                <h3 className="text-[#bef264] font-black italic uppercase text-xl tracking-tight">Carlos Santos</h3>
                <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">Técnico Especializado • Desde 2015</p>
              </div>
            </div>
            
            <div className="space-y-4 text-neutral-300 text-sm leading-relaxed">
              <div className="space-y-4 border-t border-white/5 pt-6">
                <p>
                  Carlos Santos, nascido a 10 de Maio de 1986, natural de Monsanto é funcionário da Câmara Municipal de Alcanena desde 2008 onde desempenha as funções de Assistente Técnico do sector de desporto.
                </p>
                <p>
                  Desde muito novo que está ligado á prática desportiva. Em 1997 começou uma aventura pelo mundo do atletismo e pelas mãos do seu técnico de sempre, Paulo Constantino, conseguiu atingir o seu maior sonho, ser atleta internacional.
                </p>
                <p>
                  Ao longo dos anos, quer nas camadas jovens quer já depois no escalão sênior afirmou-se como um dos melhores atletas nacionais das provas combinadas, uma disciplina bastante exigente do atletismo que conjuga provas de velocidade, saltos, lançamentos e resistência.
                </p>
                <p>
                  Para além de dezenas de títulos distritais, muitas presenças na seleção distrital, pódios nacionais, a sua carreira ficou marcada pela presença em 2 edições da Taça da Europa de Provas Combinadas, onde na edição de 2013 se classificou em 9º lugar entre os melhores da Europa ajudando Portugal a subir á 1ª liga.
                </p>
                <p>
                  Em 2017 já como veterano conseguiu vários pódios nacionais, com destaque para as 3 vezes seguidas sagrando-se Campeão Nacional de Pentatlo. No ano 2022 participou no Campeonato da Europa de Veteranos em Braga, mas uma lesão nas vésperas da competição impediram de uma prestação ao nível de medalhas.
                </p>
                <p>
                  Atualmente pratica ciclismo na vertente BTT, onde participa em resistências e provas de longa duração como o Pão de Kilo e as 24h BTT.
                </p>
                <p>
                  2012 foi o ano em que se formou como Técnico de Marcha e Corrida, dando inicio ao projeto no ano de 2015. Tem dado muito de si ás pessoas levando-lhes a sua boa disposição diária e conhecimento sobre a atividade física que foi adquirindo ao longos dos anos de experiencia.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* SIGNUP SECTION */}
        {activeTab === 'signup' && (
          <div className="space-y-6">
            <div className="glass p-8 rounded-[2.5rem] border-[#bef264]/20 bg-gradient-to-b from-[#bef264]/5 to-transparent text-center">
              <h3 className="text-white font-black italic uppercase text-xl mb-6 tracking-tight">Junta-te à Equipa!</h3>
              
              <a 
                href="https://portal.fpatletismo.pt/login" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-block w-full bg-[#bef264] text-black py-5 rounded-2xl font-black uppercase italic tracking-widest text-sm shadow-xl glow-lime hover:scale-[1.02] transition-all active:scale-95"
              >
                Clica aqui para Inscrição <i className="fas fa-external-link-alt ml-2"></i>
              </a>
            </div>
            
            <div className="px-4 space-y-6">
              <p className="text-center text-[10px] text-neutral-500 font-bold uppercase italic leading-tight">
                Para mais informações dirige-te a um dos locais de treino ou entra em contato.
              </p>

              <form onSubmit={handleFormSubmit} className="glass p-6 rounded-[2rem] border-white/5 space-y-4">
                <div className="space-y-1">
                  <label className="text-[9px] font-black uppercase text-[#bef264] tracking-widest pl-2">Nome</label>
                  <input 
                    type="text" 
                    placeholder="O teu nome"
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm font-bold placeholder:text-neutral-700 focus:border-[#bef264] outline-none transition-colors"
                    value={contactForm.name}
                    onChange={e => setContactForm({ ...contactForm, name: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[9px] font-black uppercase text-[#bef264] tracking-widest pl-2">Mensagem</label>
                  <textarea 
                    placeholder="Escreve a tua mensagem..."
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm font-bold h-24 placeholder:text-neutral-700 focus:border-[#bef264] outline-none transition-colors"
                    value={contactForm.message}
                    onChange={e => setContactForm({ ...contactForm, message: e.target.value })}
                    required
                  />
                </div>
                <button 
                  type="submit" 
                  disabled={sent}
                  className={`w-full py-4 rounded-xl font-black uppercase italic text-xs tracking-widest transition-all ${sent ? 'bg-emerald-500/20 text-emerald-500' : 'bg-white/10 text-white hover:bg-white/20'}`}
                >
                  {sent ? <><i className="fas fa-check mr-2"></i> Mensagem Enviada</> : 'Enviar Contacto'}
                </button>
                <p className="text-[8px] text-neutral-600 font-bold uppercase text-center tracking-widest">
                  Apenas o administrador terá acesso à tua mensagem
                </p>
              </form>
            </div>
          </div>
        )}

      </div>

      {/* Footer Info (Shared) */}
      <div className="p-6 text-center space-y-4 pt-12 border-t border-white/5">
        <p className="text-[9px] font-black uppercase text-neutral-600 tracking-[0.3em]">Redes Sociais</p>
        <div className="flex justify-center gap-8">
          <a href="https://www.facebook.com/cmmcalcanena" target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-[#bef264] transition-all">
            <i className="fab fa-facebook text-xl"></i>
          </a>
          <a href="https://www.instagram.com/cmmcalcanena.minde/" target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-[#bef264] transition-all">
            <i className="fab fa-instagram text-xl"></i>
          </a>
          <a href="https://www.youtube.com/@centrodemarchaecorridaalca5148" target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-[#bef264] transition-all">
            <i className="fab fa-youtube text-xl"></i>
          </a>
        </div>
        <p className="text-[10px] font-bold text-neutral-500 tracking-wider">
          cmcalcanena@gmail.com
        </p>
      </div>
    </div>
  );
};

export default AboutView;
