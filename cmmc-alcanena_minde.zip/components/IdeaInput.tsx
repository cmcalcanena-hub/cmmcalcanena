
import React, { useState } from 'react';

interface IdeaInputProps {
  onSubmit: (prompt: string) => void;
  isLoading: boolean;
}

const IdeaInput: React.FC<IdeaInputProps> = ({ onSubmit, isLoading }) => {
  const [prompt, setPrompt] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      onSubmit(prompt);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl relative group">
      <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur opacity-25 group-focus-within:opacity-50 transition duration-1000"></div>
      <div className="relative flex flex-col md:flex-row gap-2 bg-slate-900 border border-slate-700 p-2 rounded-2xl">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Ex: Quero fazer um app de delivery de café para pets..."
          className="flex-1 bg-transparent border-none text-white placeholder-slate-500 p-4 focus:ring-0 resize-none h-24 md:h-auto min-h-[60px]"
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSubmit(e);
            }
          }}
        />
        <button
          type="submit"
          disabled={isLoading || !prompt.trim()}
          className="px-8 py-4 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-blue-500/20 active:scale-95 flex items-center justify-center gap-2"
        >
          {isLoading ? (
            <i className="fas fa-spinner fa-spin"></i>
          ) : (
            <>
              Gerar Blueprint <i className="fas fa-magic"></i>
            </>
          )}
        </button>
      </div>
      <p className="mt-3 text-xs text-slate-500 text-center">
        Dica: Descreva o problema que você quer resolver e quem são seus usuários.
      </p>
    </form>
  );
};

export default IdeaInput;
